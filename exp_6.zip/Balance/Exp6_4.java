package Balance;


public class Exp6_4 {
    public static void main(String args[]) {
        logger log = new logger();
        log.logMessage("Hello");
    }
}

