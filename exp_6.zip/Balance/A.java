package Balance;

public class A {
    public void m1() {
        System.out.println("Method of public class");
    }

    protected void m2() {
        System.out.println("Method of protected class");
    }

    void m3() {
        System.out.println("Method of default class");
    }

    private void m4() {
        System.out.println("Method of private class");
    }
}

